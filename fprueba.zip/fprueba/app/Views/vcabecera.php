<div class="container">
    Bienvenidos

    <div class="text-end">
    <a href="<?php echo base_url('/')   ?>">   inicio</a>
     
    </div>

</div>